
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CC
 */
public class StoreManagerMenu extends javax.swing.JFrame {
     public void view(){
        String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.EMPLOYEES");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("EmployeeName");
            model.addColumn("EmployeeID");
            model.addColumn("Position");
            
           
            while (rs.next()) {
            Object[] rowData = new Object[10];
            rowData[0] = rs.getString("EmployeeName");
            rowData[1] = rs.getInt("EmployeeID");
            rowData[2] = rs.getString("Position");
            
           
            model.addRow(rowData);
           
}
            
            jTable1.setModel(model);
        }
        
        
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
     }
    
    
     public void ViewWareHouseStock(){
      String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.STORE");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("productName");
            model.addColumn("productID");
            model.addColumn("Quantity");
            model.addColumn("Price");
            
            
            while (rs.next()) {
            Object[] rowData = new Object[5];
            rowData[0] = rs.getString("ProductName");
            rowData[1] = rs.getInt("ProductID");
            rowData[2] = rs.getInt("Quantity");
            rowData[3] = rs.getDouble("Price");

            
            model.addRow(rowData);
}
            
            WarehouseStock1.setModel(model);
        }  
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
     }
     public void UpdateWareHouse(){
      
      String url =  "jdbc:derby://localhost:1527/BestBrighness";
       
        int productId = Integer.parseInt(TxtProductID2.getText());
        //int quantity = Integer.parseInt(txtQuantity1.getText());
        double price = Double.parseDouble(txtPrice2.getText());
        String productName =txtProductName2.getText();
       
        try  {
            Connection connection = DriverManager.getConnection(url);
            
            String sql = "UPDATE APP.STORE SET price = ?,productName = ? WHERE productId = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
           // preparedStatement.setInt(1, quantity);
            preparedStatement.setDouble(1, price);
            preparedStatement.setString(2, productName);
            preparedStatement.setInt(3, productId);

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Product update successful for ID " + productId, "Success", JOptionPane.INFORMATION_MESSAGE);
              
            } else {
                JOptionPane.showMessageDialog(this, "Product with ID " + productId + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
      }
     
      public void   View(){
        String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.TBLCUSTOMER ");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("CustomerID");
             model.addColumn("CustomerName");
            
            
            
            while (rs.next()) {
            Object[] rowData = new Object[2];
            rowData[0] = rs.getInt("CustomerID");
            rowData[1] = rs.getString("CustomerName");
            

            
            model.addRow(rowData);
           // dispose();
            //con.close();
}
            
            CustomerTable.setModel(model);
        }
        
        
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
    }
      
    /**
     * Creates new form StoreManagerMenu
     */
    public StoreManagerMenu() {
        initComponents();
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        SignIn = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        btnSignIn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtCustomerName = new javax.swing.JTextField();
        txtCustomerID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        CustomerTable = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        BtnAdd = new javax.swing.JButton();
        btnView = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        comboPosition = new javax.swing.JComboBox<>();
        txtEmployeeID = new javax.swing.JTextField();
        txtEmployeNAME = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnUpdate1 = new javax.swing.JButton();
        btnView1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtProductName2 = new javax.swing.JTextField();
        TxtProductID2 = new javax.swing.JTextField();
        txtPrice2 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        WarehouseStock1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(178, 179, 178));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(224, 240, 240));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SignIn.setBackground(new java.awt.Color(178, 179, 178));
        SignIn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("User Name");
        SignIn.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 240, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Password");
        SignIn.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 330, -1, -1));
        SignIn.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 250, 390, 30));
        SignIn.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, 400, 30));

        btnSignIn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSignIn.setForeground(new java.awt.Color(153, 153, 153));
        btnSignIn.setText("Sign In");
        btnSignIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSignInActionPerformed(evt);
            }
        });
        SignIn.add(btnSignIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 380, -1, -1));

        jPanel2.add(SignIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 700));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(166, 182, 177));
        jLabel2.setText("Manage Customers");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 40, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(166, 182, 177));
        jLabel3.setText("Manage Employees ");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 30, -1, -1));

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 30, 10, 480));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(166, 182, 177));
        jLabel4.setText("Customer Name");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(166, 182, 177));
        jLabel5.setText("Customer ID");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, -1, -1));
        jPanel2.add(txtCustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 110, 290, 30));
        jPanel2.add(txtCustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 290, 30));

        CustomerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(CustomerTable);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 510, 150));

        btnDelete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(166, 182, 177));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel2.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 440, -1, -1));

        BtnAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        BtnAdd.setForeground(new java.awt.Color(166, 182, 177));
        BtnAdd.setText("Add");
        BtnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAddActionPerformed(evt);
            }
        });
        jPanel2.add(BtnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 440, -1, -1));

        btnView.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnView.setForeground(new java.awt.Color(166, 182, 177));
        btnView.setText("View");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        jPanel2.add(btnView, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 440, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(166, 182, 177));
        jLabel6.setText("Employee Name");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 100, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(166, 182, 177));
        jLabel7.setText("EmployeeID");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 150, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(166, 182, 177));
        jLabel8.setText("Position");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 200, -1, -1));

        comboPosition.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        comboPosition.setForeground(new java.awt.Color(166, 182, 177));
        comboPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "warehouse admin", "salesperson", "store manager" }));
        jPanel2.add(comboPosition, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 190, 280, 30));
        jPanel2.add(txtEmployeeID, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 140, 280, 30));
        jPanel2.add(txtEmployeNAME, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 90, 280, 30));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(166, 182, 177));
        jButton3.setText("Add");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 460, -1, -1));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(166, 182, 177));
        jButton4.setText("View");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 460, -1, -1));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(166, 182, 177));
        jButton5.setText("Delete");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 460, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 250, 520, 180));

        jButton2.setText("next");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 570, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, 680));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Store Available Stock");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, -1, -1));

        btnUpdate1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnUpdate1.setText("Update");
        btnUpdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnUpdate1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 500, -1, -1));

        btnView1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnView1.setText("View");
        btnView1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnView1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnView1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 500, 90, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Product Name");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Product ID");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Price");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 200, -1, -1));
        jPanel1.add(txtProductName2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, 350, 30));
        jPanel1.add(TxtProductID2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 160, 350, 30));
        jPanel1.add(txtPrice2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 220, 350, 30));

        WarehouseStock1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(WarehouseStock1);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 270, 740, 210));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("Request a New Stock");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 500, 320, -1));

        jButton6.setText("next");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 580, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, 700));

        jMenu1.setText("File");

        jMenuItem1.setText("add customer & Employees");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("View available stock");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem4.setText("exit");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnView1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnView1ActionPerformed
        ViewWareHouseStock();
    }//GEN-LAST:event_btnView1ActionPerformed

    private void btnUpdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate1ActionPerformed
        UpdateWareHouse();

        ViewWareHouseStock();
    }//GEN-LAST:event_btnUpdate1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       WarehouseMenu StoreManagerMenu  = new WarehouseMenu();
        StoreManagerMenu.show();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            String EmployeeIDText = txtCustomerID.getText();

            if (EmployeeIDText.matches("\\d+")) {
                int SupplierID= Integer.parseInt(EmployeeIDText);

                String sql = "DELETE FROM APP.TBLCUSTOMER  WHERE CustomerID= ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1,SupplierID);

                int rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                    View();
                    txtCustomerID.setText(" ");
                } else {
                    JOptionPane.showMessageDialog(null, "Couldn't delete", "Error", JOptionPane.ERROR_MESSAGE);
                }

                ps.close();
            } else {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid INTEGER for CUSTOMERID", "Error", JOptionPane.ERROR_MESSAGE);

            }

            con.close();
        } catch(SQLException e) {
            System.out.println(e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid INTEGER for CUSTOMERID.");
        }

    }//GEN-LAST:event_btnDeleteActionPerformed

    private void BtnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAddActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";

        int CUSTOMERID = Integer.parseInt(txtCustomerID.getText());
        String CUSTOMERNAME  =txtCustomerName.getText();

        String state = "INSERT INTO APP.TBLCUSTOMER (CUSTOMERID, CUSTOMERNAME) VALUES ( ?, ?)";
        try{
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement(state);

            ps.setInt(1,CUSTOMERID );

            ps.setString(2,CUSTOMERNAME );

            int rowsInserted = ps.executeUpdate();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Added Successfully");
                View();
                txtCustomerID.setText(" ");
                txtCustomerName.setText(" ");
            } else {
                JOptionPane.showMessageDialog(null, "Error inserting record.");
            }

            ps.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "SQL Exception: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnAddActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
      View();
    }//GEN-LAST:event_btnViewActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";

        try {
            Connection con = DriverManager.getConnection(url);

            String  EmployeeName = txtEmployeNAME.getText();
            String Position= comboPosition.getSelectedItem().toString();
            int EmployeeID = Integer.parseInt(txtEmployeeID.getText());

            String sql = "INSERT INTO APP.EMPLOYEES ( EmployeeName ,EmployeeID ,Position ) VALUES (?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            // JOptionPane.showMessageDialog(null, "Added Succesfull");
            ps.setString(1,EmployeeName);
            ps.setInt(2,EmployeeID);
            ps.setString(3,Position);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Added Succesfull");
            txtEmployeNAME.setText(" ");
            txtEmployeeID.setText(" ");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        view();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            String EmployeeIDText = txtEmployeeID.getText().trim();

            // Check if the input is a valid integer
            if (EmployeeIDText.matches("\\d+")) {
                int EmployeeID= Integer.parseInt(EmployeeIDText);

                String sql = "DELETE FROM APP.EMPLOYEES  WHERE EMPLOYEEID= ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1,EmployeeID);

                // Execute the delete statement
                int rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Employee deleted successfully");
                    view();
                    txtEmployeeID.setText(" ");
                } else {
                    JOptionPane.showMessageDialog(null, "Couldn't delete", "Error", JOptionPane.ERROR_MESSAGE);
                }

                // Close resources
                ps.close();
            } else {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid INTEGER for CUSTOMERID", "Error", JOptionPane.ERROR_MESSAGE);

            }

            con.close();
        } catch(SQLException e) {
            System.out.println(e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid INTEGER for CUSTOMERID.");
        }

    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnSignInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSignInActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            String Username = jTextField1.getText();
            String Password = jPasswordField1.getText();

            String sql = "SELECT * FROM BTLOGINDETAILS WHERE USERNAME = ? AND PASSWORD = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, Username);
            ps.setString(2, Password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {

                JOptionPane.showMessageDialog(null, "Login Successful");
                SignIn.setVisible(false);
// this.dispose();
            } else {

                JOptionPane.showMessageDialog(null, "Wrong password or username", "Login Error", JOptionPane.ERROR_MESSAGE);
            }

            rs.close();
            ps.close();
            con.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btnSignInActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jPanel2.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        SalesMenu StoreManagerMenu = new SalesMenu();
        StoreManagerMenu.show();
        
        jPanel1.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        dispose();
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
     jPanel2.setVisible(true);
     SignIn.setVisible(false);
     jPanel1.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
       jPanel1.setVisible(true);
       jPanel2.setVisible(false);
       SignIn.setVisible(false);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StoreManagerMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StoreManagerMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StoreManagerMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StoreManagerMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StoreManagerMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAdd;
    private javax.swing.JTable CustomerTable;
    private javax.swing.JPanel SignIn;
    private javax.swing.JTextField TxtProductID2;
    private javax.swing.JTable WarehouseStock1;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSignIn;
    private javax.swing.JButton btnUpdate1;
    private javax.swing.JButton btnView;
    private javax.swing.JButton btnView1;
    private javax.swing.JComboBox<String> comboPosition;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtCustomerID;
    private javax.swing.JTextField txtCustomerName;
    private javax.swing.JTextField txtEmployeNAME;
    private javax.swing.JTextField txtEmployeeID;
    private javax.swing.JTextField txtPrice2;
    private javax.swing.JTextField txtProductName2;
    // End of variables declaration//GEN-END:variables
}

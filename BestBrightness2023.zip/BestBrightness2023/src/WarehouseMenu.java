
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CC
 */
public class WarehouseMenu extends javax.swing.JFrame {
     public void connect(){
        String url = "jdbc:derby://localhost:1527/dbRegister";
        try {
       
           Connection con = DriverManager.getConnection(url);
           System.out.println("Connected");
        }
    catch(SQLException e){
       System.out.println(e.getMessage());
            }}
     
     
     public void ViewWareHouseStock(){
      String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.WAREHOUSE");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("productName");
            model.addColumn("productID");
            model.addColumn("Quantity");
            model.addColumn("Price");
            
            
            while (rs.next()) {
            Object[] rowData = new Object[5];
            rowData[0] = rs.getString("ProductName");
            rowData[1] = rs.getInt("ProductID");
            rowData[2] = rs.getInt("Quantity");
            rowData[3] = rs.getDouble("Price");

            
            model.addRow(rowData);
}
            
            WarehouseStock.setModel(model);
        }  
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
     }
     
      public void ViewSupplies(){
      String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.SALE");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("OrderDate");
            model.addColumn("productName");
            model.addColumn("productID");
            model.addColumn("Quantity");
            model.addColumn("Price");
            
            
            while (rs.next()) {
            Object[] rowData = new Object[5];
            rowData[0] = rs.getDate("OrderDate");
            rowData[1] = rs.getString("ProductName");
            rowData[2] = rs.getInt("ProductID");
            rowData[3] = rs.getInt("Quantity");
            rowData[4] = rs.getDouble("Price");

            
            model.addRow(rowData);
}
            
            Supplierr.setModel(model);
        }  
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
     }
      public void UpdateWareHouse(){
      
      String url =  "jdbc:derby://localhost:1527/BestBrighness";
       
        int productId = Integer.parseInt(TxtProductID1.getText());
        int quantity = Integer.parseInt(txtQuantity1.getText());
        double price = Double.parseDouble(txtPrice1.getText());
        String productName =txtProductName1.getText();
       
        try  {
            Connection connection = DriverManager.getConnection(url);
            
            String sql = "UPDATE APP.WAREHOUSE SET quantity = quantity + ?, price = ?,productName = ? WHERE productId = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, quantity);
            preparedStatement.setDouble(2, price);
            preparedStatement.setString(3, productName);
            preparedStatement.setInt(4, productId);

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Product update successful for ID " + productId, "Success", JOptionPane.INFORMATION_MESSAGE);
               txtProductName1.setText(" ");
               TxtProductID1.setText(" ");
               txtQuantity1.setText(" ");  
                txtPrice1.setText(" ");        
// ViewWareHouseStock();
            } else {
                JOptionPane.showMessageDialog(this, "Product with ID " + productId + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
      }
     
     public void ViewSuppliers(){
      String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.SUPPLIERS");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("SupplierName");
            model.addColumn("SupplierID");
           
            
            
            while (rs.next()) {
            Object[] rowData = new Object[5];
            rowData[0] = rs.getString("SupplierName");
            rowData[1] = rs.getInt("SupplierID");
           

            
            model.addRow(rowData);
}
            
           jTable2 .setModel(model);
        }  
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
     }
             
    /**
     * Creates new form WarehouseMenu
     */
    public WarehouseMenu() {
        initComponents();
        connect();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        SignIn = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        btnSignIn = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtSupplierName = new javax.swing.JTextField();
        txtSupplierID = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        btnView = new javax.swing.JButton();
        BtnAdd = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Supplierr = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnSell = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtProductName = new javax.swing.JTextField();
        TxtProductID = new javax.swing.JTextField();
        txtPurchaseQuantity = new javax.swing.JTextField();
        txtPrice = new javax.swing.JTextField();
        btnBuy = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtProductName1 = new javax.swing.JTextField();
        TxtProductID1 = new javax.swing.JTextField();
        txtQuantity1 = new javax.swing.JTextField();
        txtPrice1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        WarehouseStock = new javax.swing.JTable();
        btnView1 = new javax.swing.JButton();
        btnUpdate1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(178, 179, 178));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(166, 182, 177));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(224, 240, 240));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SignIn.setBackground(new java.awt.Color(178, 179, 178));
        SignIn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("User Name");
        SignIn.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 240, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Password");
        SignIn.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 330, -1, -1));
        SignIn.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 250, 390, 30));
        SignIn.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, 400, 30));

        btnSignIn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSignIn.setForeground(new java.awt.Color(153, 153, 153));
        btnSignIn.setText("Sign In");
        btnSignIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSignInActionPerformed(evt);
            }
        });
        SignIn.add(btnSignIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 380, -1, -1));

        jPanel3.add(SignIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(166, 182, 177));
        jLabel13.setText("Managing Suppliers");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 170, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(166, 182, 177));
        jLabel14.setText("Supplier Name");
        jPanel3.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 240, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(166, 182, 177));
        jLabel15.setText("SupplierID");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, -1, -1));

        txtSupplierName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSupplierNameActionPerformed(evt);
            }
        });
        jPanel3.add(txtSupplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 240, 330, 30));
        jPanel3.add(txtSupplierID, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 300, 330, 30));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable2);

        jPanel3.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 360, 600, 170));

        btnView.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnView.setForeground(new java.awt.Color(166, 182, 177));
        btnView.setText("View");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        jPanel3.add(btnView, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 560, -1, -1));

        BtnAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        BtnAdd.setForeground(new java.awt.Color(166, 182, 177));
        BtnAdd.setText("Add");
        BtnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAddActionPerformed(evt);
            }
        });
        jPanel3.add(BtnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 560, -1, -1));

        btnDelete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(166, 182, 177));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel3.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 560, -1, -1));

        jButton3.setText("next");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 640, -1, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        Supplierr.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(Supplierr);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 360, 500, 170));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("WareHouse Available Stock");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, -1));

        btnSell.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSell.setText("Store PickUp");
        btnSell.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSellActionPerformed(evt);
            }
        });
        jPanel1.add(btnSell, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 550, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Product Name");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 200, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Product ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 250, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Quantity");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 310, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Price");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 300, -1, -1));
        jPanel1.add(txtProductName, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 200, 330, 30));
        jPanel1.add(TxtProductID, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 250, 330, 30));
        jPanel1.add(txtPurchaseQuantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 300, 110, 30));

        txtPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPriceActionPerformed(evt);
            }
        });
        jPanel1.add(txtPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 300, 120, 30));

        btnBuy.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnBuy.setText("Purchase");
        btnBuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuyActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuy, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 550, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Supplier Orders");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 20, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Product Name");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Product ID");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Quantity");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Price");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, -1));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 10, 510));
        jPanel1.add(txtProductName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 350, 30));
        jPanel1.add(TxtProductID1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 130, 350, 30));
        jPanel1.add(txtQuantity1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 180, 350, 30));
        jPanel1.add(txtPrice1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 230, 350, 30));

        WarehouseStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(WarehouseStock);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 590, 210));

        btnView1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnView1.setText("View");
        btnView1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnView1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnView1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 510, 90, -1));

        btnUpdate1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnUpdate1.setText("Update");
        btnUpdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnUpdate1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 510, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("SupplierID");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 140, -1, -1));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 140, 330, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("View");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 550, -1, -1));

        jButton4.setText("next");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 620, -1, -1));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Delivery Slip");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 40, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton2.setText("Print");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 510, -1, -1));

        jButton5.setText("next");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 620, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 730));

        jMenu1.setText("Menu");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        jMenuItem1.setText("Managing Suppliers");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Orders");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Purchase History");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem5.setText("exit");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSellActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";
int productId = Integer.parseInt(TxtProductID.getText());
int purchaseQuantity = Integer.parseInt(txtPurchaseQuantity.getText());
double price = Double.parseDouble(txtPrice.getText());
String productName = txtProductName.getText();

Connection connection = null;
try {
    connection = DriverManager.getConnection(url);
    connection.setAutoCommit(false); // Start a transaction

    // Step 1: Subtract the purchased quantity from the first table (e.g., WAREHOUSE)
    String subtractSql = "UPDATE APP.SALE SET quantity = quantity - ? WHERE productId = ?";
    PreparedStatement subtractStatement = connection.prepareStatement(subtractSql);
    subtractStatement.setInt(1, purchaseQuantity);
    subtractStatement.setInt(2, productId);

    int rowsSubtracted = subtractStatement.executeUpdate();

    
    if (rowsSubtracted > 0) {
        String addSql = "INSERT INTO APP.STORE (productId, quantity, price, productName) VALUES (?, ?, ?, ?)";
        PreparedStatement addStatement = connection.prepareStatement(addSql);
        addStatement.setInt(1, productId);
        addStatement.setInt(2, purchaseQuantity);
        addStatement.setDouble(3, price);
        addStatement.setString(4, productName);
        //addStatement.setDate(5, new java.sql.Date(Date.getTime()));

        int rowsAdded = addStatement.executeUpdate();

        if (rowsAdded > 0) {
            connection.commit(); // Commit the transaction
           
            JOptionPane.showMessageDialog(this, "Purchase successful for product ID " + productId, "Success", JOptionPane.INFORMATION_MESSAGE);
            ViewSupplies();
            ViewWareHouseStock();
            
        } else {
            connection.rollback(); // Rollback the transaction if the addition fails
            JOptionPane.showMessageDialog(this, "Failed to add to SALES table.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Product with ID " + productId + " not found in the WAREHOUSE table.", "Error", JOptionPane.ERROR_MESSAGE);
    }
} catch (SQLException ex) {
    if (connection != null) {
        try {
            connection.rollback(); // Rollback the transaction in case of an exception
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    ex.printStackTrace();
    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
} finally {
    if (connection != null) {
        try {
            connection.setAutoCommit(true); // Restore auto-commit mode
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }}
    }//GEN-LAST:event_btnSellActionPerformed

    private void btnBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuyActionPerformed
       String url = "jdbc:derby://localhost:1527/BestBrighness";
        
int productId = Integer.parseInt(TxtProductID.getText());
int purchaseQuantity = Integer.parseInt(txtPurchaseQuantity.getText());
double price = Double.parseDouble(txtPrice.getText());
String productName = txtProductName.getText();

Connection connection = null;
try {
    connection = DriverManager.getConnection(url);
    connection.setAutoCommit(false); 

    
    String subtractSql = "UPDATE APP.WAREHOUSE SET quantity = quantity - ? WHERE productId = ?";
    PreparedStatement subtractStatement = connection.prepareStatement(subtractSql);
    subtractStatement.setInt(1, purchaseQuantity);
    subtractStatement.setInt(2, productId);

    int rowsSubtracted = subtractStatement.executeUpdate();

    
    if (rowsSubtracted > 0) {
        String addSql = "INSERT INTO APP.SALE (productId, quantity, price, productName) VALUES (?, ?, ?, ?)";
        PreparedStatement addStatement = connection.prepareStatement(addSql);
        addStatement.setInt(1, productId);
        addStatement.setInt(2, purchaseQuantity);
        addStatement.setDouble(3, price);
        addStatement.setString(4, productName);
       

        int rowsAdded = addStatement.executeUpdate();

        if (rowsAdded > 0) {
            connection.commit(); // Commit the transaction
           
            JOptionPane.showMessageDialog(this, "Purchase successful for product ID " + productId, "Success", JOptionPane.INFORMATION_MESSAGE);
            ViewSupplies();
            ViewWareHouseStock();
            jTextField1.setText(" ");
            txtProductName.setText(" ");
            TxtProductID.setText(" ");
            txtPurchaseQuantity.setText(" ");
            txtPrice.setText(" ");        
                    
                    
            
        } else {
            connection.rollback(); // Rollback the transaction if the addition fails
            JOptionPane.showMessageDialog(this, "Failed to add to SALES table.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Product with ID " + productId + " not found in the WAREHOUSE table.", "Error", JOptionPane.ERROR_MESSAGE);
    }
} catch (SQLException ex) {
    if (connection != null) {
        try {
            connection.rollback(); 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    ex.printStackTrace();
    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
} finally {
    if (connection != null) {
        try {
            connection.setAutoCommit(true); 
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


    }//GEN-LAST:event_btnBuyActionPerformed

    private void txtPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPriceActionPerformed

    private void btnView1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnView1ActionPerformed
       ViewWareHouseStock();
    }//GEN-LAST:event_btnView1ActionPerformed

    private void btnUpdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate1ActionPerformed
        UpdateWareHouse();
        
        ViewWareHouseStock();
    }//GEN-LAST:event_btnUpdate1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       ViewSupplies();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM APP.Sale");
            
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel model = new DefaultTableModel();
             model.addColumn("ORDERDATE");
            model.addColumn("productName");
            model.addColumn("productID");
            model.addColumn("Quantity");
            model.addColumn("Price");
            
            
            while (rs.next()) {
            Object[] rowData = new Object[5];
            rowData[0] = rs.getString("ORDERDATE");
            rowData[1] = rs.getString("ProductName");
            rowData[2] = rs.getInt("ProductID");
            rowData[3] = rs.getInt("Quantity");
            rowData[4] = rs.getDouble("Price");

            
            model.addRow(rowData);
}
            
            jTable1.setModel(model);
        }  
         catch(SQLException e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
       ViewSuppliers();
    }//GEN-LAST:event_btnViewActionPerformed

    private void BtnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAddActionPerformed
       String url = "jdbc:derby://localhost:1527/BestBrighness";
      
        

            int SupplierID = Integer.parseInt(txtSupplierID.getText());
            String SupplierName =txtSupplierName.getText();
            
            String state = "INSERT INTO APP.SUPPLIERS (SUPPLIERID, SUPPLIERNAME) VALUES ( ?, ?)";
                try{
             Connection con = DriverManager.getConnection(url);
            PreparedStatement ps = con.prepareStatement(state);

            
            ps.setInt(1,SupplierID );     
            
            ps.setString(2,SupplierName );       
                
            
            int rowsInserted = ps.executeUpdate();

            
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Added Successfully");
                ViewSuppliers();
           txtSupplierID.setText(" ");
           txtSupplierName.setText(" ");
            } else {
                JOptionPane.showMessageDialog(null, "Error inserting record.");
            }

           
            ps.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "SQL Exception: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_BtnAddActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
      
    }//GEN-LAST:event_jTable2MouseClicked

    private void txtSupplierNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSupplierNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSupplierNameActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
         String url = "jdbc:derby://localhost:1527/BestBrighness";
    try {
        Connection con = DriverManager.getConnection(url);
        String EmployeeIDText = txtSupplierID.getText();
        
        
        if (EmployeeIDText.matches("\\d+")) {
            int SupplierID= Integer.parseInt(EmployeeIDText);
            
            String sql = "DELETE FROM APP.SUPPLIERS  WHERE SupplierID= ?";
            PreparedStatement ps = con.prepareStatement(sql); 
            ps.setInt(1,SupplierID);
            
            
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "deleted successfully");
                ViewSuppliers();
                 txtSupplierID.setText(" ");
                 
            } else {
                JOptionPane.showMessageDialog(null, "Couldn't delete", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
           
            ps.close();
        } else {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid INTEGER for SupplierId", "Error", JOptionPane.ERROR_MESSAGE);
           
        }
        
        con.close();
    } catch(SQLException e) {
        System.out.println(e.getMessage());
    } catch (NumberFormatException e) {
        System.out.println("Invalid input. Please enter a valid INTEGER for CUSTOMERID.");
    }
       
                
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnSignInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSignInActionPerformed
        String url = "jdbc:derby://localhost:1527/BestBrighness";
        try {
            Connection con = DriverManager.getConnection(url);
            String Username = jTextField2.getText();
            String Password = jPasswordField1.getText();

            String sql = "SELECT * FROM BTLOGINDETAILS WHERE USERNAME = ? AND PASSWORD = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, Username);
            ps.setString(2, Password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {

                JOptionPane.showMessageDialog(null, "Login Successful");
                SignIn.setVisible(false);
// this.dispose();
            } else {

                JOptionPane.showMessageDialog(null, "Wrong password or username", "Login Error", JOptionPane.ERROR_MESSAGE);
            }

            rs.close();
            ps.close();
            con.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btnSignInActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       jPanel3.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
      jPanel1.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
     StoreManagerMenu  WarehouseMenu = new StoreManagerMenu ();
     WarehouseMenu.show();
     jPanel2.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed
       
    }//GEN-LAST:event_jMenu1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       new WarehouseMenu().jPanel3.setVisible(true);
       SignIn.setVisible(false);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        dispose();
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
      jPanel1.setVisible(true);
      jPanel3.setVisible(false);
      SignIn.setVisible(false);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
       jPanel2.setVisible(true);
        jPanel1.setVisible(false);
      jPanel3.setVisible(false);
      SignIn.setVisible(false);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WarehouseMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WarehouseMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WarehouseMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WarehouseMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WarehouseMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAdd;
    private javax.swing.JPanel SignIn;
    private javax.swing.JTable Supplierr;
    private javax.swing.JTextField TxtProductID;
    private javax.swing.JTextField TxtProductID1;
    private javax.swing.JTable WarehouseStock;
    private javax.swing.JButton btnBuy;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSell;
    private javax.swing.JButton btnSignIn;
    private javax.swing.JButton btnUpdate1;
    private javax.swing.JButton btnView;
    private javax.swing.JButton btnView1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtPrice1;
    private javax.swing.JTextField txtProductName;
    private javax.swing.JTextField txtProductName1;
    private javax.swing.JTextField txtPurchaseQuantity;
    private javax.swing.JTextField txtQuantity1;
    private javax.swing.JTextField txtSupplierID;
    private javax.swing.JTextField txtSupplierName;
    // End of variables declaration//GEN-END:variables
}
